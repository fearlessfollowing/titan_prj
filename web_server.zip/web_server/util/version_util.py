
VERSION = 'V1.0.4_2019.03.01'

class ins_version:
    @classmethod
    def get_version(self):
        return VERSION

    @classmethod
    def get_git_version(self):
        pass