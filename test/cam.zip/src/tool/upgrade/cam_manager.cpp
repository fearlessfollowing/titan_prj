
#include "cam_manager.h"
#include "usb_camera.h"
#include "inslog.h"
#include "xml_config.h"
#include "usb_device.h"
#include "json_obj.h"
#include <fstream>
#include "usb_msg.h"
#include <unistd.h>
#include <future>

int cam_manager::power_on_all()
{
	if (INS_CAM_NUM != 8)
	{
		system("power_on.sh");
		LOGINFO("power on");
	}
	usb_device::create();

	return INS_OK;
}

int cam_manager::power_off_all()
{
	if (INS_CAM_NUM != 8)
	{
		system("power_off.sh");
		LOGINFO("power off");
	}

	usb_device::destroy();

	return INS_OK;
}

cam_manager::~cam_manager() 
{
	close_all_cam(); 
};

cam_manager::cam_manager()
{
	for (unsigned int i = 0; i < cam_num_; i++)
	{
		pid_.push_back(i+1);
	}

	master_index_ = INS_CAM_NUM - 1;

	LOGINFO("cam_manager vid:%x pid:%x %x %x %x %x %x", vid_, pid_[0], pid_[1],pid_[2],pid_[3],pid_[4],pid_[5]);
}

bool cam_manager::is_all_open()
{
	return usb_device::get()->is_all_open();
}

bool cam_manager::is_all_close()
{
	return usb_device::get()->is_all_close();
}

int cam_manager::open_all_cam()
{
	std::vector<unsigned int> index;
	for (unsigned int i = 0; i < cam_num_; i++)
	{
		index.push_back(i);
	}

	return open_cam(index);
}

int cam_manager::open_cam(std::vector<unsigned int>& index)
{
	int ret = do_open_cam(index);
	if (ret != INS_OK)
	{
		close_all_cam();
		return INS_ERR_CAMERA_OPEN;
	}
	else
	{
		return INS_OK;
	}
}

int cam_manager::do_open_cam(std::vector<unsigned int>& index)
{
	if (!map_cam_.empty())
	{
		LOGERR("camera have been open");
		return INS_ERR;
	}

	for (unsigned int i = 0; i < index.size(); i++)
	{
		if (index[i] >= cam_num_) return INS_ERR;
	}

	//wait A12 power on
	bool b_all_open = true;
	int loop_cnt = 400;
	while (--loop_cnt > 0)
	{
		b_all_open = true;
		for (unsigned int i = 0; i < index.size(); i++)
		{
			if (!usb_device::get()->is_open(pid_[index[i]]))
			{
				b_all_open = false; 
				break;
			}
		}

		if (b_all_open) break;
		else usleep(50*1000);
	}

	if (!b_all_open)
	{
		LOGERR("not all camera open");
		return INS_ERR;
	}
	else
	{
		LOGINFO("all camera open");
	}

	usleep(1000*1000); //wait A12 init ...

	for (unsigned int i = 0; i < index.size(); i++)
	{
		auto cam = std::make_shared<usb_camera>(pid_[index[i]], index[i]);
		map_cam_.insert(std::make_pair(index[i], cam));
	}

	return INS_OK;
}

void cam_manager::close_all_cam()
{
	for (auto it = map_cam_.begin(); it != map_cam_.end(); it++)
	{
		it->second->close();
	}

	map_cam_.clear();
}

int cam_manager::get_one_firmware_version(int index, std::vector<std::string>& version)
{
	auto it = map_cam_.find(index);
	if (it == map_cam_.end()) return INS_ERR;

	int ret = it->second->get_fw_version();
	RETURN_IF_NOT_OK(ret);

	ret = it->second->wait_cmd_over();
	RETURN_IF_NOT_OK(ret);

	auto result = it->second->get_result();
	json_obj root(result.c_str());
	std::string tmp;
	root.get_string("version", tmp);
	version.push_back(tmp);
	LOGINFO("index:%d firmware version:%s", it->first, tmp.c_str());

	return INS_OK;
}

int cam_manager::get_all_firmware_version(std::vector<std::string>& version)
{
	if (map_cam_.empty()) return INS_ERR_CAMERA_NOT_OPEN;

	int result = INS_OK;
	for (auto it = map_cam_.begin(); it != map_cam_.end(); it++)
	{
		int ret = it->second->get_fw_version();
	}

	for (auto it = map_cam_.begin(); it != map_cam_.end(); it++)
	{
		int ret = it->second->wait_cmd_over();
		if (ret == INS_OK)
		{
			auto res = it->second->get_result();
			json_obj root(res.c_str());
			std::string tmp;
			root.get_string("version", tmp);
			version.push_back(tmp);
			LOGINFO("index:%d firmware version:%s", it->first, tmp.c_str());
		} 
		else
		{
			result = ret;
		}
	}

	return result;
}

int cam_manager::test_spi(int index)
{
	auto it = map_cam_.find(index);
	if (it == map_cam_.end()) return INS_ERR_CAMERA_NOT_OPEN;

	int ret = it->second->test_spi();
	RETURN_IF_NOT_OK(ret);

	ret = it->second->wait_cmd_over();
	RETURN_IF_NOT_OK(ret);

	auto result = it->second->get_result();
	json_obj root_obj(result.c_str());
	int value = 0;
	root_obj.get_int("value", value);

	if (value)
	{
		return INS_ERR;
	}
	else
	{
		return INS_OK;
	}
}

int32_t cam_manager::calibration_bpc_all()
{
	int32_t ret = INS_OK;
	std::future<int32_t> futures[INS_CAM_NUM];

	for (int32_t i = 0; i < INS_CAM_NUM; i++)
	{
		futures[i] = std::async(std::launch::async, [this, i]
		{
			auto it = map_cam_.find(i);
			if (it == map_cam_.end()) 
			{
				return INS_ERR;
			}
			else
			{
				return it->second->calibration_bpc_req();
			}
		});
	}

	for (int32_t i = 0; i < INS_CAM_NUM; i++)
	{
		auto r = futures[i].get();
		if (r != INS_OK) ret = r;
	}

	LOGINFO("bpc calibration result:%d", ret);

	return ret;
}

int cam_manager::calibration_blc_all(bool reset)
{
	int32_t ret = INS_OK;
	std::future<int32_t> futures[INS_CAM_NUM];

	for (int i = 0; i < INS_CAM_NUM; i++)
	{
		futures[i] = std::async(std::launch::async, [this, i, reset]
		{
			auto it = map_cam_.find(i);
			if (it == map_cam_.end())  return INS_ERR;
			if (reset)
			{
				return it->second->calibration_blc_reset();
			}
			else
			{
				return it->second->calibration_blc_req();
			}
		});	
	}

	for (int32_t i = 0; i < INS_CAM_NUM; i++)
	{
		auto r = futures[i].get();
		if (r != INS_OK) ret = r;
	}

	LOGINFO("blc calibration result:%d", ret);

	return ret;
}

int cam_manager::upgrade(std::string file_name, std::string version)
{
	int ret = INS_OK;
	std::string md5_value;
	ret = md5_file(file_name, md5_value);
	RETURN_IF_NOT_OK(ret);

	std::thread th[cam_num_];
	int result[cam_num_];
	for (unsigned int i = 0; i < cam_num_; i++)
	{
		th[i] = std::thread([this, i, &file_name, &result, &md5_value]()
		{	
			result[i] = INS_ERR;
			int loop = 3;//如果升级失败尝试3次
			while (loop-- > 0) 
			{
				if (INS_OK == map_cam_[i]->upgrade(file_name, md5_value)) 
				{
					result[i] = INS_OK;
					break;
				}
			}
		});
	}

	for (unsigned int i = 0; i < cam_num_; i++)
	{
		INS_THREAD_JOIN(th[i]);
		if (result[i] != INS_OK) ret = INS_ERR;
	}

	RETURN_IF_NOT_OK(ret);

	ret = reboot_all_camera();
	RETURN_IF_NOT_OK(ret);

	ret = check_fw_version(version);
	RETURN_IF_NOT_OK(ret);

	return INS_OK;
}

int cam_manager::check_fw_version(std::string version)
{
	int loop_cnt = 1000;
	while (--loop_cnt > 0)
	{
		if (!is_all_open())
		{
			LOGINFO("module start reboot");
			break;
		}

		usleep(50*1000);
	}

	loop_cnt = 1000;
	while (--loop_cnt > 0)
	{
		if (is_all_open())
		{
			LOGINFO("all module reboot success");
			break;
		}

		usleep(50*1000);
	}

	if (!is_all_open())
	{
		LOGERR("not all module reboot success");
		return INS_ERR;
	}

	usleep(100*1000);

	std::vector<std::string> v_version;
	get_all_firmware_version(v_version);
	for (unsigned int i = 0; i < v_version.size(); i++)
	{
		auto pos = v_version[i].find(".", 0);
		if (pos == std::string::npos) return INS_ERR;
		std::string tmp = v_version[i].substr(pos+1);
		if (version != tmp)
		{
			LOGERR("version check fail, module version:%d %s after upgrade != req version:%d %s", 
				tmp.length(), tmp.c_str(), version.length(), version.c_str());
			return INS_ERR;
		}
	}

	return INS_OK;
}

int cam_manager::reboot_all_camera()
{
	int32_t ret = INS_OK;
	for (auto it = map_cam_.begin(); it != map_cam_.end(); it++)
	{
		auto r = it->second->reboot();
		if (r != INS_OK) ret = r;
	}

	for (auto it = map_cam_.begin(); it != map_cam_.end(); it++)
	{
		auto r = it->second->wait_cmd_over();
		if (r != INS_OK) ret = r;
	}

	return ret;
}

int cam_manager::md5_file(std::string file_name, std::string& md5_value)
{
    std::string tmp_file = "/tmp/.md5_result";
    std::string cmd = "md5sum -b " + file_name + " > " + tmp_file;
    LOGINFO("cmd:%s", cmd.c_str());
    system(cmd.c_str());

    std::ifstream file(tmp_file);
    if (!file.is_open())
    {
        LOGERR("file:%s open fail", tmp_file.c_str());
        return INS_ERR;
    }
    std::string line;
    getline(file, line);
    file.close();
    remove(tmp_file.c_str());

    LOGINFO("file:%s md5:%s", file_name.c_str(), line.c_str());

    md5_value = line;

    return INS_OK;
}

int cam_manager::get_uuid_sensorid(std::vector<std::string>& v_uuid, std::vector<std::string>& v_sensorid)
{
	for (auto it = map_cam_.begin(); it != map_cam_.end(); it++)
	{
		int ret = it->second->get_uuid_sensorid();
		RETURN_IF_NOT_OK(ret);
	}

	for (auto it = map_cam_.begin(); it != map_cam_.end(); it++)
	{
		int ret = it->second->wait_cmd_over();
		RETURN_IF_NOT_OK(ret);
		std::string result = it->second->get_result();
		json_obj root_obj(result.c_str());
		std::string uuid;
		std::string sensorid;
		root_obj.get_string("uuid", uuid);
		root_obj.get_string("sensorId", sensorid);
		if (uuid == "")
		{
			LOGERR("index:%d uuid is null", it->first);
			return INS_ERR;
		}
		if (sensorid == "")
		{
			LOGERR("index:%d sensorid is null", it->first);
			return INS_ERR;
		}

		v_uuid[it->first] = uuid;
		v_sensorid[it->first] = sensorid;
		LOGINFO("index:%d uuid:%s sensorid:%s", it->first, uuid.c_str(), sensorid.c_str());
	}

	return INS_OK;
}

int cam_manager::send_awb_data(unsigned int index, std::string file_name)
{
	int ret = send_data(index, file_name, AMBA_FRAME_CB_AWB);
	if (ret == INS_OK)
	{
		LOGINFO("---index:%d send awb data success", index);
	}
	else
	{
		LOGERR("---index:%d send awb data fail", index);
	}
	return ret;
}

int cam_manager::send_lp_data(unsigned int index, std::string file_name)
{
	int ret = send_data(index, file_name, AMBA_FRAME_CB_BRIGHT);
	if (ret == INS_OK)
	{
		LOGINFO("---index:%d send lp data success", index);
	}
	else
	{
		LOGERR("---index:%d send lp data fail", index);
	}
	return ret;
}

int cam_manager::send_vig_maxvalue(unsigned int index, unsigned char* data, unsigned int size)
{
	int ret = send_buff(index, data, size, AMBA_FRAME_CB_VIG_MAXVALUE);
	if (ret == INS_OK)
	{
		LOGINFO("---index:%d send vig maxvalue success", index);
	}
	else
	{
		LOGERR("---index:%d send vig maxvalue fail", index);
	}
	return ret;
}

int cam_manager::send_data(unsigned int index, std::string file_name, int type)
{
	auto it = map_cam_.find(index);
	if (it == map_cam_.end()) return INS_ERR;

	return it->second->send_calibration_data(file_name, type);
}

int cam_manager::send_buff(unsigned int index, unsigned char* data, unsigned int size, int type)
{
	auto it = map_cam_.find(index);
	if (it == map_cam_.end()) return INS_ERR;

	return it->second->send_calibration_data(data, size, type);
}

int cam_manager::get_all_options(std::string property, std::vector<std::string>& v_value)
{
	int ret = INS_OK;
	for (auto it = map_cam_.begin(); it != map_cam_.end(); it++)
	{
		std::string value;
		ret = it->second->get_options(property, value);
		BREAK_IF_NOT_OK(ret);
		v_value.push_back(value);
	}

	return ret;
}

