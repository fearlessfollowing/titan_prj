#ifndef _INS_UUID_H_
#define _INS_UUID_H_

#include <string>

std::string ins_uuid_gen();

#endif