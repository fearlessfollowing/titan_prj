
// #ifndef _INS_MD5_H_
// #define _INS_MD5_H_

// int md5_file(std::string file_name, std::string& md5_value);

// #endif