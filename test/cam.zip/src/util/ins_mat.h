#ifndef _INS_MAT_H_
#define _INS_MAT_H_

class ins_mat_3d
{
public:
    double m[9] = {0.0};
};

class ins_mat_4f
{
public:
    float m[4] = {0.0};
};

#endif