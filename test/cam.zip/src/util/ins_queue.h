#ifndef _INS_QUEUE_
#define _INS_QUEUE_

#include <mutex>
#include <deque>

template <class T>
class ins_queue
{
public:
    void enqueue(const T& item)
    {
        std::lock_guard<std::mutex> lock(mtx_);
        queue_.push_back(item);
    }

    bool dequeue(T& item)
    {
        std::lock_guard<std::mutex> lock(mtx_);
        if (queue_.empty()) return false;
        item = queue_.front();
        queue_.pop_front();
        return true;
    }

    bool empty()
    {
        return queue_.empty();
    }

    unsigned int size()
    {
        return queue_.size();
    }

private:
    std::mutex mtx_;
    std::deque<T> queue_;
};

#endif