linux compile:
cd jni
make -j8

